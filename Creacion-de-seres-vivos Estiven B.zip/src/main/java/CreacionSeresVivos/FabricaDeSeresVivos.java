package CreacionSeresVivos;
import CreacionSeresVivos.tierra.Humano;
import CreacionSeresVivos.tierra.Oso;
import CreacionSeresVivos.cielo.Alien;

public class FabricaDeSeresVivos implements Creador {
    public SerVivo crearSeresVivos(String tipo) {
        if (tipo.equals("humano")) {
            return new Humano();
       } else if (tipo.equals("alien")) {
            return new Alien();
       } else if (tipo.equals("oso")) {
            return new Oso();
        }
        return null;
    }
}
