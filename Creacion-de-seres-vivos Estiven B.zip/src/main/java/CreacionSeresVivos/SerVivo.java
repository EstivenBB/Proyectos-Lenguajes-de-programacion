package CreacionSeresVivos;

public abstract class SerVivo{
  public abstract void nacer();
  public abstract void crecer();
  public abstract void reproducirse();
  public abstract void morir();

}