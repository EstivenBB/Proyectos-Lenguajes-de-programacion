package CreacionSeresVivos;

public interface Creador {
    SerVivo crearSeresVivos(String tipo);
}
