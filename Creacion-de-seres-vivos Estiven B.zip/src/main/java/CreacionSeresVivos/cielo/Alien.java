package CreacionSeresVivos.cielo;
import CreacionSeresVivos.tierra.SerTierra;
import CreacionSeresVivos.SerVivo;

public class Alien extends SerVivo implements SerTierra, SerCielo {
  public void nacer(){
    System.out.println("Alien naciendo...");
  };
  public void crecer(){
     System.out.println("Alien creciendo...");
  };
  public void reproducirse(){
     System.out.println("Alien reproduciendose...");
  };
  public void morir(){
     System.out.println("El alien ha muerto...");
  };
  public void correr(){
     System.out.println("Alien corriendo...");
  };
  public void excavar(){
     System.out.println("Alien excavando...");
  };
  public void trepar(){
     System.out.println("Alien trepando...");
  };
  public void volar(){
     System.out.println("Alien volando");
  };
  public void cambiarDeDimension(){
     System.out.println("El alien ha cambiado de dimension...");
  };
  public void planear(){
     System.out.println("Alien planeando...");
  };
}
