package CreacionSeresVivos.cielo;

public interface SerCielo{
  public void volar();
  public void cambiarDeDimension();
  public void planear();

}

