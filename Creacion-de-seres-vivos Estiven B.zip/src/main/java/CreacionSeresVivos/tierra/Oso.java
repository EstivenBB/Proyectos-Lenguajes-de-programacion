package CreacionSeresVivos.tierra;
import CreacionSeresVivos.SerVivo;

public class Oso extends SerVivo implements SerTierra {
  public void nacer(){
    System.out.println("Oso naciendo...");
  };
  public void crecer(){
     System.out.println("Oso creciendo...");
  };
  public void reproducirse(){
     System.out.println("Oso reproduciendose...");
  };
  public void morir(){
     System.out.println("El Oso ha muerto...");
  };
  public void correr(){
     System.out.println("Oso corriendo...");
  };
  public void excavar(){
     System.out.println("Oso excavando...");
  };
  public void trepar(){
     System.out.println("Oso trepando...");
  };
}
