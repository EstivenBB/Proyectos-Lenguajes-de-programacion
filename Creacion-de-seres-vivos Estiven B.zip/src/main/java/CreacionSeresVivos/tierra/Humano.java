package CreacionSeresVivos.tierra;
import CreacionSeresVivos.cielo.SerCielo;
import CreacionSeresVivos.SerVivo;

public class Humano extends SerVivo implements SerTierra, SerCielo {
  public void nacer(){
    System.out.println("Humano naciendo...");
  };
  public void crecer(){
     System.out.println("Humano creciendo...");
  };
  public void reproducirse(){
     System.out.println("Humano reproduciendose...");
  };
  public void morir(){
     System.out.println("El humano ha muerto...");
  };
  public void correr(){
     System.out.println("Humano corriendo...");
  };
  public void excavar(){
     System.out.println("Humano excavando...");
  };
  public void trepar(){
     System.out.println("Humano trepando...");
  };
  public void volar(){
     System.out.println("Humano volando...");
  };
  public void cambiarDeDimension(){
     System.out.println("El humano ha cambiado de dimension...");
  };
  public void planear(){
     System.out.println("Humano planeando...");
  };
}
