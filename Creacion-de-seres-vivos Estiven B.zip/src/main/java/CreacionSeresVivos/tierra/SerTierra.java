package CreacionSeresVivos.tierra;


public interface SerTierra{
  public void correr();
  public void excavar();
  public void trepar();
}


