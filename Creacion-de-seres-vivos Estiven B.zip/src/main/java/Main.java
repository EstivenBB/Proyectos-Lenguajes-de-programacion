// Código creado por Estiven Betancur Betancur Semestre 2, Lenguajes de Programación, Universidad EAFIT

import CreacionSeresVivos.FabricaDeSeresVivos;
import CreacionSeresVivos.Creador;
import CreacionSeresVivos.SerVivo;
import CreacionSeresVivos.tierra.Humano;
import CreacionSeresVivos.cielo.Alien;
import CreacionSeresVivos.tierra.Oso;

public class Main {
    public static void main(String[] args) {
        // Creamos una instancia de la fábrica de seres vivos
        Creador creador = new FabricaDeSeresVivos();

        // Creamos un ser vivo terrestre (Humano)
        SerVivo humano = creador.crearSeresVivos("humano");
        if (humano instanceof Humano) {
            Humano humanoTerrestre = (Humano) humano;
            humanoTerrestre.crecer();
            humanoTerrestre.trepar();
            humanoTerrestre.volar();
        }

        // Creamos un ser vivo celeste (Alien)
        SerVivo alien = creador.crearSeresVivos("alien");
        if (alien instanceof Alien) {
            Alien alienCielo = (Alien) alien;
            alienCielo.morir();
            alienCielo.cambiarDeDimension();
            alienCielo.excavar();
        }

        // Creamos un ser vivo terrestre (Oso)
        SerVivo oso = creador.crearSeresVivos("oso");
        if (oso instanceof Oso) {
            Oso osoTerrestre = (Oso) oso;
            osoTerrestre.correr();
            osoTerrestre.trepar();
        }
    }
}
